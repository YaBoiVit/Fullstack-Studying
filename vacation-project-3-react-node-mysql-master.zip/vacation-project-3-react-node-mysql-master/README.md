# Project For John Bryce 

This project is about vacations.
- User: can see vacations, like\unliked vacations.
- Admin: can edit vacations, add new vacations, and see a chart with all the vacations users are following

You can find it also here: https://vacations-project.netlify.app

## The Project

In the project directory, you can find:

- Client side built with React and using Chartjs
- Server side built with Nodejs
- Database with MySQL




